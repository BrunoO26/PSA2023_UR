﻿Imports System
Imports Snap7

Public Class MainForm

    Dim Buffer(65536) As Byte ' Buffer
    Dim Buffer_B(65536) As Byte
    Dim Buffer_X(65536) As Byte
    Dim Buffer_Y(65536) As Byte
    Dim Buffer_RZ(65536) As Byte
    Dim Client As Snap7.S7Client ' Client Object
    Public DiagX As Boolean = False
    Public Start_UR As Boolean = False
    Public Stop_UR As Boolean = False
    Public Pause_UR As Boolean = False

    Private Sub ShowResult(ByVal Result As Integer)
        ' This function returns a textual explaination of the error code
        TextError.Text = Client.ErrorText(Result)
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Client = New S7Client

        If IntPtr.Size = 4 Then
            Text = Text + " - Running 32 bit Code"
        Else
            Text = Text + " - Running 64 bit Code"
        End If

    End Sub

    Private Sub ConnectBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConnectBtn.Click
        Dim Result As Integer
        Dim Rack As Integer = System.Convert.ToInt32(TxtRack.Text)
        Dim Slot As Integer = System.Convert.ToInt32(TxtSlot.Text)

        Result = Client.ConnectTo(TxtIP.Text, Rack, Slot)
        ShowResult(Result)
        If Result = 0 Then
            TxtIP.Enabled = False
            TxtRack.Enabled = False
            TxtSlot.Enabled = False
            ConnectBtn.Enabled = False
            DisconnectBtn.Enabled = True
            TxtDB.Enabled = True
            TxtSize.Enabled = True
            ReadBtn.Enabled = True
            Btn_Read_Mw.Enabled = True
            Btn_Run.Enabled = True
            Btn_Stop.Enabled = True
            Bt_Diag.Enabled = True

            Btn_Automatico.Enabled = True
            Btn_Manual.Enabled = True
            Btn_StartUR10.Enabled = True
            Btn_StopUR10.Enabled = True
            Btn_PauseUR10.Enabled = True
            Txt_X.Enabled = True
            Txt_Y.Enabled = True
            Txt_Rz.Enabled = True
            Txt_Npecas.Enabled = True

            Btn_PLC_Status.Enabled = True
            TxtDump.Enabled = True

            Timer1.Enabled = True

        End If
    End Sub

    Private Sub DisconnectBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisconnectBtn.Click
        Client.Disconnect()
        TxtIP.Enabled = True
        TxtRack.Enabled = True
        TxtSlot.Enabled = True
        ConnectBtn.Enabled = True
        DisconnectBtn.Enabled = False
        TxtDB.Enabled = False
        TxtSize.Enabled = False
        ReadBtn.Enabled = False
        TxtDump.Enabled = False
        Txt_X.Enabled = False
        Txt_Y.Enabled = False
        Txt_Rz.Enabled = False
        Txt_Npecas.Enabled = False
    End Sub

    Private Sub ReadBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReadBtn.Click
        ' Declaration separated from the code for readability
        Dim DBNumber As Integer
        Dim Size As Integer
        Dim Result As Integer
        Dim c As Integer
        Dim s As String
        '
        TxtDump.Text = ""
        DBNumber = System.Convert.ToInt32(TxtDB.Text)
        Size = System.Convert.ToInt32(TxtSize.Text)
        ' Read "Size" bytes from the DB "DBNumber" starting from 0 and puts them into Buffer.
        ' S7 - 300 (OK)
        Result = Client.DBRead(DBNumber, 0, Size, Buffer)

        ' Leituta de Flags - MW20.. +10
        ' S7 1200 - Ainda nºao está a funcionar
        'Result = Client.ReadArea(132, 1, 2, 5, 6, Buffer)
        ShowResult(Result)
        ' If OK dumps the data (quick and dirty)
        Txt_Final.Text = ""
        Txt_Read.Text = ""
        If Result = 0 Then

            For c = 0 To Size - 1
                s = Hex$(Buffer(c))
                If s.Length = 1 Then
                    s = "0" + s
                End If
                TxtDump.Text = TxtDump.Text + "0x" + s + Chr(13) + Chr(10)
                Txt_Read.Text = Txt_Read.Text + CStr(Buffer(c)) + Chr(13) + Chr(10)

                If (c Mod 2 = 0) Then
                    Txt_Final.Text = Txt_Final.Text + CStr(Buffer(c + 1) + Buffer(c) * 256) + Chr(13) + Chr(10)
                End If

            Next
        End If
    End Sub


    Private Sub Btn_Read_Mw_Click(sender As Object, e As EventArgs) Handles Btn_Read_Mw.Click
        ' Declaration separated from the code for readability
        Dim MBNumber As Integer
        Dim Size As Integer
        Dim Result As Integer
        Dim c As Integer
        Dim s As String
        '
        TxtDump.Text = ""
        MBNumber = System.Convert.ToInt32(TxtDB.Text)
        Size = System.Convert.ToInt32(TxtSize.Text)

        ' Read "Size" bytes from the DB "MBNumber" starting from 0 and puts them into Buffer.
        Result = Client.AsMBRead(MBNumber, Size, Buffer)

        ' Leituta de Flags - MW20.. +10
        ' Result = Client.ReadArea(131, 0, MBNumber, Size, 8, Buffer)

        ' CommPlc.nResultado = CommPlc.Client.ABRead(CommPlc.nPlcPrimeiroByteOutput,
        '                              CommPlc.nPlcNumByteOutput, CommPlc.pPlcOutputData)

        ShowResult(Result)
        ' If OK dumps the data (quick and dirty)
        Txt_Final.Text = ""
        Txt_Read.Text = ""
        If Result = 0 Then

            For c = 0 To Size - 1
                s = Hex$(Buffer(c))
                If s.Length = 1 Then
                    s = "0" + s
                End If
                TxtDump.Text = TxtDump.Text + "0x" + s + Chr(13) + Chr(10)
                Txt_Read.Text = Txt_Read.Text + CStr(Buffer(c)) + Chr(13) + Chr(10)

                If (c Mod 2 = 0) Then
                    Txt_Final.Text = Txt_Final.Text + CStr(Buffer(c + 1) + Buffer(c) * 256) + Chr(13) + Chr(10)
                End If

            Next
        End If
    End Sub


    Private Sub Btn_PLC_Status_Click(sender As Object, e As EventArgs) Handles Btn_PLC_Status.Click
        Dim Result As Integer
        Dim Status As Integer

        Result = Client.PlcGetStatus(Status)

        If Status = 8 Then
            Txt_PLC_Status.Text = "Running"
        End If

        If Status = 4 Then
            Txt_PLC_Status.Text = "Stop"
        End If
    End Sub

    Private Sub Btn_Run_Click(sender As Object, e As EventArgs) Handles Btn_Run.Click
        ' PLC Run
        Client.PlcHotStart()
    End Sub

    Private Sub Btn_Stop_Click(sender As Object, e As EventArgs) Handles Btn_Stop.Click
        ' PLC Stop
        Client.PlcStop()

    End Sub

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    '############## BOTÕES DE AUTOMÁTICO / MANUAL #################

    Private Sub Btn_Automatico_Click(sender As Object, e As EventArgs) Handles Btn_Automatico.Click
        ' Declaration separated from the code for readability
        Dim Size As Integer
        Dim Result As Integer
        Dim c As Integer
        Dim s As String

        Buffer_B(0) = 1
        ' Write Flags - MW20.. +10
        ' 10.0 - Automatic Mode
        Result = Client.WriteArea(131, 0, 10, 1, 2, Buffer_B)
        ' Read Mode 
        Result = Client.ReadArea(131, 0, 10, 1, 2, Buffer_B)

        ShowResult(Result)
        If Result = 0 Then
            Txt_Modo_Func.Text = "Automático"
            For c = 0 To Size - 1
                s = Hex$(Buffer_B(c))
                If s.Length = 1 Then
                    s = "0" + s
                End If
                'TxtDump.Text = TxtDump.Text + "0x" + s + Chr(13) + Chr(10)
            Next
        End If

    End Sub
    Private Sub Btn_Manual_Click(sender As Object, e As EventArgs) Handles Btn_Manual.Click
        ' Declaration separated from the code for readability
        Dim Size As Integer
        Dim Result As Integer
        Dim c As Integer
        Dim s As String

        Buffer_B(0) = 0
        ' Write Flags - MW20.. +10
        ' 10.0 - Automatic Mode
        Result = Client.WriteArea(131, 0, 10, 1, 2, Buffer_B)

        ' Read Mode 
        Result = Client.ReadArea(131, 0, 10, 1, 2, Buffer_B)


        ShowResult(Result)
        If Result = 0 Then
            Txt_Modo_Func.Text = "Manual"
            For c = 0 To Size - 1
                s = Hex$(Buffer_B(c))
                If s.Length = 1 Then
                    s = "0" + s
                End If
                TxtDump.Text = TxtDump.Text + "0x" + s + Chr(13) + Chr(10)
            Next
        End If
    End Sub

    '############## BOTÕES DE START/STOP/PAUSE UR10 ##################

    Private Sub Btn_StartUR10_Click(sender As Object, e As EventArgs) Handles Btn_StartUR10.Click
        ' Declaration separated from the code for readability
        Dim Result_Start As Boolean

        Buffer_B(0) = 1
        ' 100.0 - Start_UR
        Start_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
        ' Read Mode 
        Result_Start = Client.ReadArea(131, 0, 100, 1, 2, Buffer_B)

        If Result_Start = 0 Then
            Txt_Robot_Status.Text = "Running"
            Buffer_B(0) = 0
            Stop_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
            Pause_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
            Buffer_B(0) = 1
            '100.0 - Start_UR
            Start_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
        End If
    End Sub

    Private Sub Btn_StopUR10_Click(sender As Object, e As EventArgs) Handles Btn_StopUR10.Click
        ' Declaration separated from the code for readability
        Dim Result_Stop As Boolean

        Buffer_B(0) = 2
        ' 100.1 - Stop_UR
        Stop_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
        ' Read Mode 
        Result_Stop = Client.ReadArea(131, 0, 100, 1, 2, Buffer_B)

        If Result_Stop = 0 Then
            Txt_Robot_Status.Text = "Stopped"
            Buffer_B(0) = 0
            Start_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
            Pause_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
            Buffer_B(0) = 2
            ' 100.1 - Stop_UR
            Stop_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
        End If
    End Sub
    Private Sub Btn_PauseUR10_Click(sender As Object, e As EventArgs) Handles Btn_PauseUR10.Click
        Dim Result_Pause As Boolean

        Buffer_B(0) = 4
        ' 100.2 - Pause_UR
        Pause_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
        ' Read Mode 
        Result_Pause = Client.ReadArea(131, 0, 100, 1, 2, Buffer_B)

        If Result_Pause = 0 Then
            Txt_Robot_Status.Text = "Paused"
            Buffer_B(0) = 0
            Start_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
            Stop_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
            Buffer_B(0) = 4
            ' 100.2 - Pause_UR
            Pause_UR = Client.WriteArea(131, 0, 100, 1, 2, Buffer_B)
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ' Leitura ciclica de variáveis
        ' Declaration separated from the code for readability
        Dim MBNumber As Integer
        Dim Size As Integer
        Dim Result As Integer
        Dim c As Integer

        Txt_Npecas.Text = ""
        Txt_X.Text = ""
        Txt_Y.Text = ""
        Txt_Rz.Text = ""

        '##################    CONTADOR DE PEÇAS   ###############################
        MBNumber = 104
        Size = 8

        Result = Client.AsMBRead(MBNumber, Size, Buffer)

        ShowResult(Result)
        ' If OK dumps the data (quick and dirty)
        If Result = 0 Then
            For c = 0 To 1
                If (c Mod 2 = 0) Then
                    Txt_Npecas.Text = Txt_Npecas.Text + CStr(Buffer(c + 1) + Buffer(c) * 256) + Chr(13) + Chr(10)
                End If
            Next
            For c = 2 To 3
                If (c Mod 2 = 0) Then
                    Txt_X.Text = Txt_X.Text + CStr(Buffer(c + 1) + Buffer(c) * 256) + Chr(13) + Chr(10)
                End If
            Next
            For c = 4 To 5
                If (c Mod 2 = 0) Then
                    Txt_Y.Text = Txt_Y.Text + CStr(Buffer(c + 1) + Buffer(c) * 256) + Chr(13) + Chr(10)
                End If
            Next
            For c = 5 To 6
                If (c Mod 2 = 0) Then
                    Txt_Rz.Text = Txt_Rz.Text + CStr(Buffer(c + 1) + Buffer(c) * 256) + Chr(13) + Chr(10)
                End If
            Next
        End If
    End Sub

    Private Sub Bt_Diag_Click(sender As Object, e As EventArgs) Handles Bt_Diag.Click
        If Not DiagX Then
            Txt_Read.Visible = True
            TxtDump.Visible = True
            Txt_Final.Visible = True
            DiagX = True
        Else
            Txt_Read.Visible = False
            TxtDump.Visible = False
            Txt_Final.Visible = False
            DiagX = False


        End If

    End Sub

End Class
