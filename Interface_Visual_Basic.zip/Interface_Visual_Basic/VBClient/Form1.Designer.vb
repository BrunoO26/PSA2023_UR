﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextError = New System.Windows.Forms.TextBox()
        Me.TxtIP = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtRack = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtSlot = New System.Windows.Forms.TextBox()
        Me.ConnectBtn = New System.Windows.Forms.Button()
        Me.DisconnectBtn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtDB = New System.Windows.Forms.TextBox()
        Me.TxtDump = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtSize = New System.Windows.Forms.TextBox()
        Me.ReadBtn = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txt_Read = New System.Windows.Forms.TextBox()
        Me.Txt_Final = New System.Windows.Forms.TextBox()
        Me.Btn_Read_Mw = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Btn_PLC_Status = New System.Windows.Forms.Button()
        Me.Txt_PLC_Status = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Btn_Run = New System.Windows.Forms.Button()
        Me.Btn_Stop = New System.Windows.Forms.Button()
        Me.Btn_Automatico = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Btn_StartUR10 = New System.Windows.Forms.Button()
        Me.Btn_StopUR10 = New System.Windows.Forms.Button()
        Me.Txt_X = New System.Windows.Forms.TextBox()
        Me.Btn_PauseUR10 = New System.Windows.Forms.Button()
        Me.Btn_Manual = New System.Windows.Forms.Button()
        Me.Label_X = New System.Windows.Forms.Label()
        Me.Label_Y = New System.Windows.Forms.Label()
        Me.Label_Rz = New System.Windows.Forms.Label()
        Me.Txt_Y = New System.Windows.Forms.TextBox()
        Me.Txt_Rz = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Txt_Npecas = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Bt_Diag = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Txt_Modo_Func = New System.Windows.Forms.TextBox()
        Me.Txt_Robot_Status = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TextError
        '
        Me.TextError.BackColor = System.Drawing.Color.White
        Me.TextError.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TextError.ForeColor = System.Drawing.Color.Black
        Me.TextError.Location = New System.Drawing.Point(0, 651)
        Me.TextError.Margin = New System.Windows.Forms.Padding(4)
        Me.TextError.Name = "TextError"
        Me.TextError.ReadOnly = True
        Me.TextError.Size = New System.Drawing.Size(1062, 22)
        Me.TextError.TabIndex = 0
        '
        'TxtIP
        '
        Me.TxtIP.Location = New System.Drawing.Point(17, 94)
        Me.TxtIP.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtIP.Name = "TxtIP"
        Me.TxtIP.Size = New System.Drawing.Size(132, 22)
        Me.TxtIP.TabIndex = 1
        Me.TxtIP.Text = "192.168.0.1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 72)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "IP Address"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(164, 72)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Rack"
        '
        'TxtRack
        '
        Me.TxtRack.Location = New System.Drawing.Point(164, 94)
        Me.TxtRack.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtRack.Name = "TxtRack"
        Me.TxtRack.Size = New System.Drawing.Size(57, 22)
        Me.TxtRack.TabIndex = 2
        Me.TxtRack.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(238, 72)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Slot"
        '
        'TxtSlot
        '
        Me.TxtSlot.Location = New System.Drawing.Point(238, 94)
        Me.TxtSlot.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtSlot.Name = "TxtSlot"
        Me.TxtSlot.Size = New System.Drawing.Size(57, 22)
        Me.TxtSlot.TabIndex = 3
        Me.TxtSlot.Text = "0"
        '
        'ConnectBtn
        '
        Me.ConnectBtn.Location = New System.Drawing.Point(16, 137)
        Me.ConnectBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.ConnectBtn.Name = "ConnectBtn"
        Me.ConnectBtn.Size = New System.Drawing.Size(133, 28)
        Me.ConnectBtn.TabIndex = 4
        Me.ConnectBtn.Text = "Connect"
        Me.ConnectBtn.UseVisualStyleBackColor = True
        '
        'DisconnectBtn
        '
        Me.DisconnectBtn.Enabled = False
        Me.DisconnectBtn.Location = New System.Drawing.Point(163, 137)
        Me.DisconnectBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.DisconnectBtn.Name = "DisconnectBtn"
        Me.DisconnectBtn.Size = New System.Drawing.Size(133, 28)
        Me.DisconnectBtn.TabIndex = 8
        Me.DisconnectBtn.Text = "Disconnect"
        Me.DisconnectBtn.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(310, 81)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 16)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "S7300"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(310, 113)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 16)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "S71200/1500"
        '
        'TxtDB
        '
        Me.TxtDB.Enabled = False
        Me.TxtDB.Location = New System.Drawing.Point(307, 210)
        Me.TxtDB.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtDB.Name = "TxtDB"
        Me.TxtDB.Size = New System.Drawing.Size(59, 22)
        Me.TxtDB.TabIndex = 5
        Me.TxtDB.Text = "22"
        '
        'TxtDump
        '
        Me.TxtDump.BackColor = System.Drawing.Color.White
        Me.TxtDump.Enabled = False
        Me.TxtDump.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtDump.ForeColor = System.Drawing.Color.Black
        Me.TxtDump.Location = New System.Drawing.Point(335, 260)
        Me.TxtDump.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtDump.Multiline = True
        Me.TxtDump.Name = "TxtDump"
        Me.TxtDump.ReadOnly = True
        Me.TxtDump.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TxtDump.Size = New System.Drawing.Size(141, 121)
        Me.TxtDump.TabIndex = 12
        Me.TxtDump.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(183, 213)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 16)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "DB/MW/..."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(449, 213)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(78, 16)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Size (Bytes)"
        '
        'TxtSize
        '
        Me.TxtSize.Enabled = False
        Me.TxtSize.Location = New System.Drawing.Point(569, 210)
        Me.TxtSize.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtSize.Name = "TxtSize"
        Me.TxtSize.Size = New System.Drawing.Size(59, 22)
        Me.TxtSize.TabIndex = 6
        Me.TxtSize.Text = "10"
        '
        'ReadBtn
        '
        Me.ReadBtn.Enabled = False
        Me.ReadBtn.Location = New System.Drawing.Point(27, 234)
        Me.ReadBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.ReadBtn.Name = "ReadBtn"
        Me.ReadBtn.Size = New System.Drawing.Size(129, 28)
        Me.ReadBtn.TabIndex = 16
        Me.ReadBtn.Text = "DB Read"
        Me.ReadBtn.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(310, 97)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(89, 16)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "S7400/WinAC"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(420, 81)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 16)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Rack=0, Slot=2"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(420, 97)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(99, 16)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "See HW Config"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(420, 113)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(96, 16)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Rack=0, Slot=0"
        '
        'Txt_Read
        '
        Me.Txt_Read.BackColor = System.Drawing.Color.White
        Me.Txt_Read.Enabled = False
        Me.Txt_Read.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Read.ForeColor = System.Drawing.Color.Black
        Me.Txt_Read.Location = New System.Drawing.Point(185, 260)
        Me.Txt_Read.Margin = New System.Windows.Forms.Padding(4)
        Me.Txt_Read.Multiline = True
        Me.Txt_Read.Name = "Txt_Read"
        Me.Txt_Read.ReadOnly = True
        Me.Txt_Read.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Read.Size = New System.Drawing.Size(144, 121)
        Me.Txt_Read.TabIndex = 21
        Me.Txt_Read.Visible = False
        '
        'Txt_Final
        '
        Me.Txt_Final.BackColor = System.Drawing.Color.White
        Me.Txt_Final.Enabled = False
        Me.Txt_Final.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Final.ForeColor = System.Drawing.Color.Black
        Me.Txt_Final.Location = New System.Drawing.Point(483, 260)
        Me.Txt_Final.Margin = New System.Windows.Forms.Padding(4)
        Me.Txt_Final.Multiline = True
        Me.Txt_Final.Name = "Txt_Final"
        Me.Txt_Final.ReadOnly = True
        Me.Txt_Final.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Final.Size = New System.Drawing.Size(144, 121)
        Me.Txt_Final.TabIndex = 22
        Me.Txt_Final.Visible = False
        '
        'Btn_Read_Mw
        '
        Me.Btn_Read_Mw.Enabled = False
        Me.Btn_Read_Mw.Location = New System.Drawing.Point(24, 279)
        Me.Btn_Read_Mw.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_Read_Mw.Name = "Btn_Read_Mw"
        Me.Btn_Read_Mw.Size = New System.Drawing.Size(129, 28)
        Me.Btn_Read_Mw.TabIndex = 23
        Me.Btn_Read_Mw.Text = "MW Read"
        Me.Btn_Read_Mw.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(308, 14)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(416, 25)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "PSA 22/23 - Bin Picking UR10 + Visão 2D"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(181, 240)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(57, 16)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "Decimal"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(332, 242)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(87, 16)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "Hexadecimal"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(480, 240)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(40, 16)
        Me.Label15.TabIndex = 27
        Me.Label15.Text = "Word"
        '
        'Btn_PLC_Status
        '
        Me.Btn_PLC_Status.Enabled = False
        Me.Btn_PLC_Status.Location = New System.Drawing.Point(686, 137)
        Me.Btn_PLC_Status.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_PLC_Status.Name = "Btn_PLC_Status"
        Me.Btn_PLC_Status.Size = New System.Drawing.Size(129, 28)
        Me.Btn_PLC_Status.TabIndex = 28
        Me.Btn_PLC_Status.Text = "PLC Status"
        Me.Btn_PLC_Status.UseVisualStyleBackColor = True
        '
        'Txt_PLC_Status
        '
        Me.Txt_PLC_Status.Location = New System.Drawing.Point(687, 97)
        Me.Txt_PLC_Status.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_PLC_Status.Name = "Txt_PLC_Status"
        Me.Txt_PLC_Status.Size = New System.Drawing.Size(131, 22)
        Me.Txt_PLC_Status.TabIndex = 29
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(684, 78)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(72, 16)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "PLC Status"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(419, 149)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(0, 16)
        Me.Label17.TabIndex = 32
        '
        'Btn_Run
        '
        Me.Btn_Run.Enabled = False
        Me.Btn_Run.Location = New System.Drawing.Point(694, 254)
        Me.Btn_Run.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_Run.Name = "Btn_Run"
        Me.Btn_Run.Size = New System.Drawing.Size(129, 28)
        Me.Btn_Run.TabIndex = 33
        Me.Btn_Run.Text = "PLC Run"
        Me.Btn_Run.UseVisualStyleBackColor = True
        '
        'Btn_Stop
        '
        Me.Btn_Stop.Enabled = False
        Me.Btn_Stop.Location = New System.Drawing.Point(694, 292)
        Me.Btn_Stop.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_Stop.Name = "Btn_Stop"
        Me.Btn_Stop.Size = New System.Drawing.Size(129, 28)
        Me.Btn_Stop.TabIndex = 34
        Me.Btn_Stop.Text = "PLC Stop"
        Me.Btn_Stop.UseVisualStyleBackColor = True
        '
        'Btn_Automatico
        '
        Me.Btn_Automatico.Enabled = False
        Me.Btn_Automatico.Location = New System.Drawing.Point(17, 471)
        Me.Btn_Automatico.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_Automatico.Name = "Btn_Automatico"
        Me.Btn_Automatico.Size = New System.Drawing.Size(129, 28)
        Me.Btn_Automatico.TabIndex = 35
        Me.Btn_Automatico.Text = "Automatic"
        Me.Btn_Automatico.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Btn_StartUR10
        '
        Me.Btn_StartUR10.Enabled = False
        Me.Btn_StartUR10.Location = New System.Drawing.Point(176, 471)
        Me.Btn_StartUR10.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_StartUR10.Name = "Btn_StartUR10"
        Me.Btn_StartUR10.Size = New System.Drawing.Size(129, 28)
        Me.Btn_StartUR10.TabIndex = 39
        Me.Btn_StartUR10.Text = "Start UR 10"
        Me.Btn_StartUR10.UseVisualStyleBackColor = True
        '
        'Btn_StopUR10
        '
        Me.Btn_StopUR10.Enabled = False
        Me.Btn_StopUR10.Location = New System.Drawing.Point(176, 503)
        Me.Btn_StopUR10.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_StopUR10.Name = "Btn_StopUR10"
        Me.Btn_StopUR10.Size = New System.Drawing.Size(129, 28)
        Me.Btn_StopUR10.TabIndex = 42
        Me.Btn_StopUR10.Text = "Stop UR10"
        Me.Btn_StopUR10.UseVisualStyleBackColor = True
        '
        'Txt_X
        '
        Me.Txt_X.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_X.Location = New System.Drawing.Point(396, 472)
        Me.Txt_X.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_X.Name = "Txt_X"
        Me.Txt_X.Size = New System.Drawing.Size(80, 30)
        Me.Txt_X.TabIndex = 43
        Me.Txt_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_PauseUR10
        '
        Me.Btn_PauseUR10.Enabled = False
        Me.Btn_PauseUR10.Location = New System.Drawing.Point(176, 535)
        Me.Btn_PauseUR10.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_PauseUR10.Name = "Btn_PauseUR10"
        Me.Btn_PauseUR10.Size = New System.Drawing.Size(129, 28)
        Me.Btn_PauseUR10.TabIndex = 53
        Me.Btn_PauseUR10.Text = "Pause UR10"
        Me.Btn_PauseUR10.UseVisualStyleBackColor = True
        '
        'Btn_Manual
        '
        Me.Btn_Manual.Enabled = False
        Me.Btn_Manual.Location = New System.Drawing.Point(17, 503)
        Me.Btn_Manual.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_Manual.Name = "Btn_Manual"
        Me.Btn_Manual.Size = New System.Drawing.Size(129, 28)
        Me.Btn_Manual.TabIndex = 54
        Me.Btn_Manual.Text = "Manual"
        Me.Btn_Manual.UseVisualStyleBackColor = True
        '
        'Label_X
        '
        Me.Label_X.AutoSize = True
        Me.Label_X.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_X.Location = New System.Drawing.Point(345, 471)
        Me.Label_X.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_X.Name = "Label_X"
        Me.Label_X.Size = New System.Drawing.Size(27, 25)
        Me.Label_X.TabIndex = 55
        Me.Label_X.Text = "X"
        '
        'Label_Y
        '
        Me.Label_Y.AutoSize = True
        Me.Label_Y.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Y.Location = New System.Drawing.Point(345, 503)
        Me.Label_Y.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_Y.Name = "Label_Y"
        Me.Label_Y.Size = New System.Drawing.Size(26, 25)
        Me.Label_Y.TabIndex = 56
        Me.Label_Y.Text = "Y"
        Me.Label_Y.UseMnemonic = False
        '
        'Label_Rz
        '
        Me.Label_Rz.AutoSize = True
        Me.Label_Rz.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Rz.Location = New System.Drawing.Point(345, 535)
        Me.Label_Rz.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_Rz.Name = "Label_Rz"
        Me.Label_Rz.Size = New System.Drawing.Size(37, 25)
        Me.Label_Rz.TabIndex = 57
        Me.Label_Rz.Text = "Rz"
        Me.Label_Rz.UseMnemonic = False
        '
        'Txt_Y
        '
        Me.Txt_Y.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Y.Location = New System.Drawing.Point(396, 503)
        Me.Txt_Y.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Y.Name = "Txt_Y"
        Me.Txt_Y.Size = New System.Drawing.Size(80, 30)
        Me.Txt_Y.TabIndex = 58
        Me.Txt_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_Rz
        '
        Me.Txt_Rz.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Rz.Location = New System.Drawing.Point(396, 535)
        Me.Txt_Rz.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Rz.Name = "Txt_Rz"
        Me.Txt_Rz.Size = New System.Drawing.Size(80, 30)
        Me.Txt_Rz.TabIndex = 59
        Me.Txt_Rz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(548, 471)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(145, 25)
        Me.Label18.TabIndex = 60
        Me.Label18.Text = "Parts Counter"
        '
        'Txt_Npecas
        '
        Me.Txt_Npecas.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Npecas.Location = New System.Drawing.Point(723, 470)
        Me.Txt_Npecas.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Npecas.Name = "Txt_Npecas"
        Me.Txt_Npecas.Size = New System.Drawing.Size(80, 30)
        Me.Txt_Npecas.TabIndex = 61
        Me.Txt_Npecas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(150, 625)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(154, 18)
        Me.Label19.TabIndex = 62
        Me.Label19.Text = "Bruno Oliveira | 93090"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(350, 625)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(156, 18)
        Me.Label20.TabIndex = 63
        Me.Label20.Text = "Carlos Ribeiro | 98637"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(550, 625)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(167, 18)
        Me.Label21.TabIndex = 64
        Me.Label21.Text = "Catarina Pereira | 98650"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(750, 625)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(141, 18)
        Me.Label22.TabIndex = 65
        Me.Label22.Text = "João Neves | 98544"
        '
        'Bt_Diag
        '
        Me.Bt_Diag.Enabled = False
        Me.Bt_Diag.Location = New System.Drawing.Point(694, 328)
        Me.Bt_Diag.Margin = New System.Windows.Forms.Padding(4)
        Me.Bt_Diag.Name = "Bt_Diag"
        Me.Bt_Diag.Size = New System.Drawing.Size(129, 28)
        Me.Bt_Diag.TabIndex = 66
        Me.Bt_Diag.Text = "Diag"
        Me.Bt_Diag.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(17, 535)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(104, 16)
        Me.Label23.TabIndex = 67
        Me.Label23.Text = "Operating Mode"
        '
        'Txt_Modo_Func
        '
        Me.Txt_Modo_Func.Location = New System.Drawing.Point(18, 553)
        Me.Txt_Modo_Func.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Modo_Func.Name = "Txt_Modo_Func"
        Me.Txt_Modo_Func.Size = New System.Drawing.Size(131, 22)
        Me.Txt_Modo_Func.TabIndex = 68
        Me.Txt_Modo_Func.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_Robot_Status
        '
        Me.Txt_Robot_Status.Location = New System.Drawing.Point(174, 588)
        Me.Txt_Robot_Status.Margin = New System.Windows.Forms.Padding(2)
        Me.Txt_Robot_Status.Name = "Txt_Robot_Status"
        Me.Txt_Robot_Status.Size = New System.Drawing.Size(131, 22)
        Me.Txt_Robot_Status.TabIndex = 70
        Me.Txt_Robot_Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(173, 568)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 16)
        Me.Label24.TabIndex = 69
        Me.Label24.Text = "Robot Status"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ClientSize = New System.Drawing.Size(1062, 673)
        Me.Controls.Add(Me.Txt_Robot_Status)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Txt_Modo_Func)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Bt_Diag)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Txt_Npecas)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Txt_Rz)
        Me.Controls.Add(Me.Txt_Y)
        Me.Controls.Add(Me.Label_Rz)
        Me.Controls.Add(Me.Label_Y)
        Me.Controls.Add(Me.Label_X)
        Me.Controls.Add(Me.Btn_Manual)
        Me.Controls.Add(Me.Btn_PauseUR10)
        Me.Controls.Add(Me.Txt_X)
        Me.Controls.Add(Me.Btn_StopUR10)
        Me.Controls.Add(Me.Btn_StartUR10)
        Me.Controls.Add(Me.Btn_Automatico)
        Me.Controls.Add(Me.Btn_Stop)
        Me.Controls.Add(Me.Btn_Run)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Txt_PLC_Status)
        Me.Controls.Add(Me.Btn_PLC_Status)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Btn_Read_Mw)
        Me.Controls.Add(Me.Txt_Final)
        Me.Controls.Add(Me.Txt_Read)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.ReadBtn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TxtSize)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TxtDump)
        Me.Controls.Add(Me.TxtDB)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DisconnectBtn)
        Me.Controls.Add(Me.ConnectBtn)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtSlot)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtRack)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtIP)
        Me.Controls.Add(Me.TextError)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.Text = "SNAP7 - Demo 27.03.2017"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextError As System.Windows.Forms.TextBox
    Friend WithEvents TxtIP As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtRack As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtSlot As System.Windows.Forms.TextBox
    Friend WithEvents ConnectBtn As System.Windows.Forms.Button
    Friend WithEvents DisconnectBtn As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtDB As System.Windows.Forms.TextBox
    Friend WithEvents TxtDump As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TxtSize As System.Windows.Forms.TextBox
    Friend WithEvents ReadBtn As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Read As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Final As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Read_Mw As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Btn_PLC_Status As System.Windows.Forms.Button
    Friend WithEvents Txt_PLC_Status As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Btn_Run As System.Windows.Forms.Button
    Friend WithEvents Btn_Stop As System.Windows.Forms.Button
    Friend WithEvents Btn_Automatico As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Btn_StartUR10 As System.Windows.Forms.Button
    Friend WithEvents Btn_StopUR10 As System.Windows.Forms.Button
    Friend WithEvents Txt_X As System.Windows.Forms.TextBox
    Friend WithEvents Btn_PauseUR10 As Button
    Friend WithEvents Btn_Manual As Button
    Friend WithEvents Label_X As Label
    Friend WithEvents Label_Y As Label
    Friend WithEvents Label_Rz As Label
    Friend WithEvents Txt_Y As TextBox
    Friend WithEvents Txt_Rz As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Txt_Npecas As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Bt_Diag As Button
    Friend WithEvents Label23 As Label
    Friend WithEvents Txt_Modo_Func As TextBox
    Friend WithEvents Txt_Robot_Status As TextBox
    Friend WithEvents Label24 As Label
End Class
